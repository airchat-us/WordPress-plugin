=== Airchat ===
Contributors: Airchat
Tags: bot,airchat
Requires at least: 3.6
Tested up to: 5.2
Stable tag: 1.0.0

Adds Airchat bot widget to your site.

== Description ==
The plugin will add a bot from https://airchat.us on all pages of your wordpress site.  Just add bot ID from airchat.us to widget\'s settings and that\'s all you need.

== Installation ==
1. Install this plugin by uploading the `airchat` directory to the `/wp-content/plugins/` directory. 
2. Activate \'Airchat\' plugin through the `Plugins` menu in WordPress.
3. Insert Bot ID by going to the `Settings > Airchat` menu.